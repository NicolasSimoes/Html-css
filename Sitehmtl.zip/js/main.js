$('.slider-principal').slick({
  dots: true,
  infinite: false,
  speed: 300,
  slidesToShow: 1
  
 })




